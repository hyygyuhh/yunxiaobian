export default class EmptyShim {}
